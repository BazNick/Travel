module.exports = function (grunt) {
  grunt.loadNpmTasks('grunt-contrib-sass');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.initConfig ({
    pkg: grunt.file.readJSON('package.json'),
    sass: {
      styles: { //имя можно придумывать любое, т.к. у меня стили, я придумал имя styles
        files: {
          "styles.css": "sass/styles.scss"
        }
      }
    },
    watch: {
      sass: {
        files: ["sass/*.scss", "*.html"],
        tasks: 'sass'
    }
  }
  });
};
